# PytorchDeepLearing

# ImageSegment Model
> There are some Model NetWorks of 3D ImageSegment and 2D ImageSegment

## ImageSegment Nets
> There are Unet and Vnet Family all has 2d and 3d version.

# ImageSegment Loss Function
> There are some loss functions of 3D ImageSegment and 2D ImageSegment

## How to Use
i have reimplemented the image segmentation loss functions with pytorch1.10.0

there are binary_crossentropy,dice_loss,focal_loss_sigmod etc all has 2d and 3d version.

there are categorical loss functions of crossentropy,dice_loss,focal_loss etc all has 2d and 3d version.

MS-SSIM loss and SSIM loss for calculating image similarity.

centerline dice loss for vessel segmentation

there are 9 type of segment metric,including dice,surface disatance,jaccard,VOE,RVD,FNR,FPR,ASSD,RMSD,MSD,etc.

flask_app.py is the demo example of the Flask Deep Learning Segmentation Model Service Deployment.

## Contact
* https://github.com/junqiangchen
* email: 1207173174@qq.com
* WeChat Public number: 最新医学影像技术
